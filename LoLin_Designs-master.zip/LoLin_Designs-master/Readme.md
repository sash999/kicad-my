# LoLin Designs

## **Disclaimer**: I have NO idea what I'm doing when it comes to KiCad. I just drew this because I wanted to have a proper drawing of the layout of the LoLin NodeMCU "V3" dev boards that I accdientally ordered

If there's an interest in more information, please leave an "issue", or a message for me. I would be glad to share anything more with interested parties.